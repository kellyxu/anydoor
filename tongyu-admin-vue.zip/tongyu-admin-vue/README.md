# 瞳宇后台管理系统（Vue3 版）

基于 **Vue3 + TypeScript + Pinia + Element Plus + Vue Router** 构建的管理后台项目，功能对齐 React 版本：

- 数据仪表盘
- 用户管理 / 用户详情
- 角色管理
- 权限管理
- 设备管理 / 设备详情
- OTA 设置 / OTA 详情
- 登录鉴权（路由守卫 + 本地登录态持久化）

## 技术栈

- Vue 3
- TypeScript
- Pinia
- Element Plus
- Vue Router
- Vite

## 本地启动

```bash
npm install
npm run dev
```

浏览器访问：`http://localhost:5173`

## 账号示例

- `zhang.chen@example.com`
- `li.wei@example.com`
- `wang.yao@example.com`（该账号为禁用状态，不可登录）

统一密码：`123456`

## 校验命令

```bash
npm run lint
npm run build
```

## 项目结构（简化）

```text
src/
  layout/
  mock/
  router/
  stores/
  types/
  views/
    auth/
    dashboard/
    users/
    roles/
    permissions/
    devices/
    ota/
    errors/
```
