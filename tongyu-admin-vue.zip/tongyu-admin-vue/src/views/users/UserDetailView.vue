<template>
  <div class="page-wrap">
    <el-page-header content="用户详情" @back="router.push('/users')" />

    <el-empty v-if="!user" description="未找到该用户" />

    <template v-else>
      <el-card shadow="never">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="用户ID">{{ user.id }}</el-descriptions-item>
          <el-descriptions-item label="姓名">{{ user.name }}</el-descriptions-item>
          <el-descriptions-item label="邮箱">{{ user.email }}</el-descriptions-item>
          <el-descriptions-item label="手机号">{{ user.phone }}</el-descriptions-item>
          <el-descriptions-item label="角色">{{ roleName }}</el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag :type="user.status === 'active' ? 'success' : 'info'">
              {{ user.status === 'active' ? '启用' : '停用' }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="创建时间">
            {{ dayjs(user.createdAt).format('YYYY-MM-DD HH:mm') }}
          </el-descriptions-item>
          <el-descriptions-item label="最后登录">
            {{ dayjs(user.lastLoginAt).format('YYYY-MM-DD HH:mm') }}
          </el-descriptions-item>
        </el-descriptions>
      </el-card>

      <el-card shadow="never">
        <template #header>名下设备</template>
        <el-table :data="ownedDevices" stripe>
          <el-table-column prop="name" label="设备名称" min-width="180" />
          <el-table-column prop="model" label="型号" min-width="130" />
          <el-table-column prop="serialNumber" label="序列号" min-width="170" />
          <el-table-column label="状态" min-width="100">
            <template #default="{ row }">
              <el-tag
                :type="row.status === 'online' ? 'success' : row.status === 'offline' ? 'info' : 'warning'"
              >
                {{ deviceStatusText(row.status) }}
              </el-tag>
            </template>
          </el-table-column>
        </el-table>
      </el-card>

      <el-card shadow="never">
        <template #header>关联 OTA 任务</template>
        <el-table :data="operatorOtas" stripe>
          <el-table-column prop="name" label="任务名称" min-width="200" />
          <el-table-column prop="targetVersion" label="目标版本" min-width="120" />
          <el-table-column prop="targetDeviceCount" label="设备数" min-width="100" />
          <el-table-column prop="successRate" label="成功率" min-width="100">
            <template #default="{ row }">{{ row.successRate }}%</template>
          </el-table-column>
          <el-table-column prop="createdAt" label="创建时间" min-width="160" />
        </el-table>
      </el-card>
    </template>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import dayjs from 'dayjs'
import { useAppStore } from '@/stores/app'
import type { Device } from '@/types/models'

const route = useRoute()
const router = useRouter()
const appStore = useAppStore()

const userId = computed(() => String(route.params.userId ?? ''))
const user = computed(() => appStore.getUserById(userId.value))
const roleName = computed(() => {
  if (!user.value) {
    return '-'
  }
  return appStore.roleMap.get(user.value.roleId)?.name ?? user.value.roleId
})

const ownedDevices = computed(() => appStore.getDevicesByOwnerId(userId.value))
const operatorOtas = computed(() => appStore.getOtaByOperatorId(userId.value))

const deviceStatusText = (status: Device['status']) => {
  if (status === 'online') return '在线'
  if (status === 'offline') return '离线'
  return '预警'
}
</script>

<style scoped>
.page-wrap {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
</style>
