<script setup lang="ts">
import { computed, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { useAppStore } from '@/stores/app'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const appStore = useAppStore()
const authStore = useAuthStore()

const query = reactive({
  keyword: '',
})

const roleNameById = computed<Record<string, string>>(() => {
  const map: Record<string, string> = {}
  appStore.roleList.forEach((role) => {
    map[role.id] = role.name
  })
  return map
})

const filteredUsers = computed(() => {
  const keyword = query.keyword.trim().toLowerCase()
  if (!keyword) {
    return appStore.userList
  }
  return appStore.userList.filter((user) => {
    const roleName = roleNameById.value[user.roleId] ?? user.roleId
    return (
      user.name.toLowerCase().includes(keyword) ||
      user.email.toLowerCase().includes(keyword) ||
      roleName.toLowerCase().includes(keyword)
    )
  })
})

function goDetail(userId: string) {
  router.push(`/users/${userId}`)
}
</script>

<template>
  <el-space direction="vertical" fill :size="16">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>用户管理</span>
        </div>
      </template>
      <el-input
        v-model="query.keyword"
        clearable
        placeholder="搜索用户名 / 邮箱 / 角色"
        style="max-width: 360px; margin-bottom: 16px"
      />
      <el-table :data="filteredUsers" border stripe>
        <el-table-column prop="name" label="姓名" min-width="120" />
        <el-table-column prop="email" label="邮箱" min-width="200" />
        <el-table-column label="角色" min-width="140">
          <template #default="{ row }">
            <el-tag>{{ roleNameById[row.roleId] ?? row.roleId }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="120">
          <template #default="{ row }">
            <el-tag :type="row.status === 'active' ? 'success' : 'info'">
              {{ row.status === 'active' ? '启用' : '停用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="lastLoginAt" label="最后登录" min-width="180" />
        <el-table-column label="操作" width="120" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="goDetail(row.id)">详情</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div style="margin-top: 12px; color: #909399">
        当前登录用户：{{ authStore.currentUser?.name ?? '-' }}
      </div>
    </el-card>
  </el-space>
</template>
