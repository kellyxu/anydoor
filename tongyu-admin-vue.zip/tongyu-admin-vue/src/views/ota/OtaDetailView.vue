<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAppStore } from '@/stores/app'

const route = useRoute()
const router = useRouter()
const appStore = useAppStore()

const otaId = computed(() => String(route.params.otaId))
const detail = computed(() => appStore.getOtaById(otaId.value))
</script>

<template>
  <div v-if="detail" class="page">
    <el-page-header @back="router.push('/ota')">
      <template #content>
        <span class="text-large font-600 mr-3">OTA 详情 - {{ detail.name }}</span>
      </template>
    </el-page-header>

    <el-card class="section-card">
      <el-descriptions :column="2" border>
        <el-descriptions-item label="任务ID">{{ detail.id }}</el-descriptions-item>
        <el-descriptions-item label="任务名称">{{ detail.name }}</el-descriptions-item>
        <el-descriptions-item label="目标版本">{{ detail.targetVersion }}</el-descriptions-item>
        <el-descriptions-item label="发布通道">{{ detail.channel }}</el-descriptions-item>
        <el-descriptions-item label="目标设备数">{{ detail.targetDeviceCount }}</el-descriptions-item>
        <el-descriptions-item label="成功率">{{ detail.successRate }}%</el-descriptions-item>
        <el-descriptions-item label="状态">
          <el-tag :type="detail.status === 'finished' ? 'success' : detail.status === 'publishing' ? 'primary' : 'info'">
            {{ detail.status }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="创建时间">{{ detail.createdAt }}</el-descriptions-item>
        <el-descriptions-item label="发布说明" :span="2">{{ detail.releaseNote }}</el-descriptions-item>
      </el-descriptions>
    </el-card>
  </div>
  <el-empty v-else description="未找到 OTA 任务" />
</template>

<style scoped>
.page {
  display: grid;
  gap: 16px;
}

.section-card {
  border-radius: 10px;
}
</style>
