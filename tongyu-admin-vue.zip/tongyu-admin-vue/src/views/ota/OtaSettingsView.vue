<template>
  <div class="view-root">
    <el-page-header content="OTA 设置" />
    <el-card class="view-card">
      <el-table :data="store.otaList" row-key="id">
        <el-table-column prop="name" label="任务名称" min-width="220" />
        <el-table-column prop="targetVersion" label="版本" width="140" />
        <el-table-column prop="channel" label="通道" width="120" />
        <el-table-column label="状态" width="120">
          <template #default="{ row }">
            <el-tag :type="row.status === 'finished' ? 'success' : row.status === 'publishing' ? 'warning' : 'info'">
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="targetDeviceCount" label="目标设备" width="120" />
        <el-table-column label="操作" width="120" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link @click="router.push(`/ota/${row.id}`)">详情</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useAppStore } from '@/stores/app'

const router = useRouter()
const store = useAppStore()
</script>
