<script setup lang="ts">
import { useAppStore } from '@/stores/app'

const appStore = useAppStore()
</script>

<template>
  <div class="page-wrap">
    <el-page-header content="数据仪表盘" />

    <el-row :gutter="16" style="margin-top: 12px">
      <el-col v-for="item in appStore.dashboardStats" :key="item.id" :xs="24" :sm="12" :md="12" :lg="6">
        <el-card shadow="hover">
          <el-statistic :title="item.title" :value="item.value" />
          <div class="card-suffix">{{ item.suffix }}</div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="16" style="margin-top: 16px">
      <el-col :xs="24" :lg="12">
        <el-card shadow="never" header="设备状态分布">
          <div class="status-row">
            <span>在线设备</span>
            <el-tag type="success">{{ appStore.onlineDeviceCount }}</el-tag>
          </div>
          <el-progress
            :percentage="Math.round((appStore.onlineDeviceCount / Math.max(appStore.deviceList.length, 1)) * 100)"
          />

          <div class="status-row">
            <span style="margin-top: 12px">预警设备</span>
            <el-tag type="warning">{{ appStore.warningDeviceCount }}</el-tag>
          </div>
          <el-progress
            status="warning"
            :percentage="Math.round((appStore.warningDeviceCount / Math.max(appStore.deviceList.length, 1)) * 100)"
          />
        </el-card>
      </el-col>
      <el-col :xs="24" :lg="12">
        <el-card shadow="never" header="最近 OTA 策略">
          <el-table :data="appStore.otaList" size="small">
            <el-table-column prop="name" label="策略名称" min-width="180" />
            <el-table-column prop="targetVersion" label="目标版本" width="120" />
            <el-table-column prop="channel" label="通道" width="100" />
            <el-table-column prop="successRate" label="成功率" width="120">
              <template #default="{ row }">{{ row.successRate }}%</template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<style scoped>
.page-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.card-suffix {
  color: var(--el-text-color-secondary);
  margin-top: 8px;
}

.status-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 8px;
}
</style>
