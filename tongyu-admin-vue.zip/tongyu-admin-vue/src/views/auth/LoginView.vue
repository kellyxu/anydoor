<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useAuthStore } from '@/stores/auth'
import './LoginView.css'

type LoginForm = {
  username: string
  password: string
}

const authStore = useAuthStore()
const router = useRouter()
const route = useRoute()
const loading = ref(false)

const form = reactive<LoginForm>({
  username: 'zhang.chen@example.com',
  password: '123456',
})

const onSubmit = async () => {
  loading.value = true
  const success = authStore.login(form.username, form.password)
  loading.value = false
  if (!success) {
    ElMessage.error('用户名或密码错误（示例密码：123456）')
    return
  }
  ElMessage.success('登录成功')
  const redirect = (route.query.redirect as string) || '/dashboard'
  await router.replace(redirect)
}
</script>

<template>
  <div class="login-page">
    <el-card class="login-card" shadow="hover">
      <div class="login-brand">
        <img src="/tongyu-logo.svg" alt="瞳宇后台管理系统" class="login-brand__logo" />
        <div>
          <h2 class="login-brand__title">瞳宇后台管理系统</h2>
          <p class="login-brand__subtitle">AI 眼镜设备管理平台</p>
        </div>
      </div>
      <el-form label-position="top" @submit.prevent="onSubmit">
        <el-form-item label="用户名（邮箱）">
          <el-input v-model="form.username" placeholder="请输入邮箱账号" clearable />
        </el-form-item>
        <el-form-item label="密码">
          <el-input v-model="form.password" type="password" placeholder="请输入密码" show-password />
        </el-form-item>
        <el-button type="primary" :loading="loading" class="login-btn" @click="onSubmit">登录</el-button>
      </el-form>
      <p class="login-tips">
        示例账号：zhang.chen@example.com / li.wei@example.com / wang.yao@example.com<br />
        示例密码：123456
      </p>
    </el-card>
  </div>
</template>
