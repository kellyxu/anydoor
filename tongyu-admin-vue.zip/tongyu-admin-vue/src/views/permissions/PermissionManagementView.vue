<script setup lang="ts">
import { computed } from 'vue'
import { useAppStore } from '@/stores/app'

const appStore = useAppStore()

const tableData = computed(() => appStore.permissionList)
</script>

<template>
  <el-space direction="vertical" :size="16" fill style="width: 100%">
    <el-card>
      <template #header>
        <span>权限管理</span>
      </template>
      <el-table :data="tableData" stripe>
        <el-table-column prop="name" label="权限名称" min-width="180" />
        <el-table-column prop="code" label="权限编码" min-width="180" />
        <el-table-column prop="resource" label="资源" min-width="120" />
        <el-table-column prop="action" label="动作" min-width="120" />
        <el-table-column prop="description" label="描述" min-width="240" />
      </el-table>
    </el-card>
  </el-space>
</template>
