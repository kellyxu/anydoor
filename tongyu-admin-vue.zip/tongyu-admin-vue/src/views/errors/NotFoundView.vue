<template>
  <div style="padding: 32px">
    <el-empty description="页面不存在">
      <el-button type="primary" @click="goHome">返回首页</el-button>
    </el-empty>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'

const router = useRouter()

function goHome() {
  void router.replace('/dashboard')
}
</script>
