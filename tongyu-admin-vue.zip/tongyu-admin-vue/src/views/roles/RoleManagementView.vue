<script setup lang="ts">
import { computed } from 'vue'
import { useAppStore } from '@/stores/app'

const appStore = useAppStore()

const roleRows = computed(() =>
  appStore.roleList.map((role) => ({
    ...role,
    permissionNames: role.permissionIds
      .map((id) => appStore.permissionList.find((permission) => permission.id === id)?.name ?? id)
      .join(' / '),
  })),
)
</script>

<template>
  <div class="page-wrap">
    <el-card>
      <template #header>
        <div class="page-card-header">
          <span>角色管理</span>
        </div>
      </template>
      <el-table :data="roleRows" border>
        <el-table-column prop="name" label="角色名称" min-width="180" />
        <el-table-column prop="description" label="描述" min-width="240" />
        <el-table-column prop="memberCount" label="成员数" min-width="100" />
        <el-table-column prop="permissionNames" label="权限" min-width="320" />
      </el-table>
    </el-card>
  </div>
</template>
