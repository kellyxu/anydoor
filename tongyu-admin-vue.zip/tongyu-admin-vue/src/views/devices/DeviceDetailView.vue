<script setup lang="ts">
import { ArrowLeft } from '@element-plus/icons-vue'
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAppStore } from '@/stores/app'

const route = useRoute()
const router = useRouter()
const appStore = useAppStore()

const deviceId = computed(() => String(route.params.deviceId ?? ''))
const device = computed(() => appStore.getDeviceById(deviceId.value))
</script>

<template>
  <div v-if="device" class="page-wrap">
    <div class="page-header">
      <el-button :icon="ArrowLeft" text @click="router.push('/devices')">返回设备列表</el-button>
      <el-text tag="h2" class="page-title">设备详情 - {{ device.name }}</el-text>
    </div>

    <el-card shadow="never" class="section-card">
      <el-descriptions :column="2" border>
        <el-descriptions-item label="设备ID">{{ device.id }}</el-descriptions-item>
        <el-descriptions-item label="设备名称">{{ device.name }}</el-descriptions-item>
        <el-descriptions-item label="设备型号">{{ device.model }}</el-descriptions-item>
        <el-descriptions-item label="固件版本">{{ device.firmwareVersion }}</el-descriptions-item>
        <el-descriptions-item label="序列号">{{ device.serialNumber }}</el-descriptions-item>
        <el-descriptions-item label="最后上报">{{ device.lastSeenAt }}</el-descriptions-item>
        <el-descriptions-item label="状态">
          <el-tag :type="device.status === 'online' ? 'success' : device.status === 'offline' ? 'info' : 'warning'">
            {{ device.status === 'online' ? '在线' : device.status === 'offline' ? '离线' : '预警' }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="所属区域">{{ device.location }}</el-descriptions-item>
      </el-descriptions>
    </el-card>

    <el-card shadow="never">
      <el-space size="large" wrap>
        <el-statistic title="当前温度" :value="25.8" suffix="°C" />
        <el-statistic title="当前湿度" :value="68.2" suffix="%" />
        <el-statistic title="剩余电量" :value="87" suffix="%" />
      </el-space>
    </el-card>
  </div>
  <el-empty v-else description="未找到设备信息" />
</template>

<style scoped>
.page-wrap {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.page-header {
  display: flex;
  align-items: center;
  gap: 8px;
}

.page-title {
  margin: 0;
  font-size: 20px;
  font-weight: 600;
}

.section-card {
  margin-bottom: 0;
}
</style>
