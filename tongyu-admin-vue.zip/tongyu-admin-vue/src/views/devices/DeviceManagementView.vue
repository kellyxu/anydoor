<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAppStore } from '@/stores/app'
import type { Device } from '@/types/models'

const router = useRouter()
const appStore = useAppStore()
const keyword = ref('')

const filteredDevices = computed(() => {
  const target = keyword.value.trim().toLowerCase()
  if (!target) {
    return appStore.deviceList
  }
  return appStore.deviceList.filter((item) =>
    [item.name, item.serialNumber, item.model].join(' ').toLowerCase().includes(target),
  )
})

const statusTagType = (status: Device['status']) => {
  if (status === 'online') return 'success'
  if (status === 'offline') return 'info'
  return 'warning'
}

const statusText = (status: Device['status']) => {
  if (status === 'online') return '在线'
  if (status === 'offline') return '离线'
  return '预警'
}

const goDetail = (id: string) => {
  router.push(`/devices/${id}`)
}
</script>

<template>
  <div class="page-wrap">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>设备管理</span>
          <el-input v-model="keyword" placeholder="按设备名/序列号/型号搜索" clearable style="max-width: 280px" />
        </div>
      </template>
      <el-table :data="filteredDevices" stripe>
        <el-table-column prop="name" label="设备名称" min-width="160" />
        <el-table-column prop="serialNumber" label="序列号" min-width="180" />
        <el-table-column prop="model" label="型号" min-width="120" />
        <el-table-column label="状态" min-width="100">
          <template #default="{ row }">
            <el-tag :type="statusTagType(row.status)">{{ statusText(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="firmwareVersion" label="固件版本" min-width="120" />
        <el-table-column prop="lastSeenAt" label="最后上报" min-width="180" />
        <el-table-column label="操作" fixed="right" min-width="100">
          <template #default="{ row }">
            <el-button link type="primary" @click="goDetail(row.id)">查看详情</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<style scoped>
.page-wrap {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
</style>
