import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/auth/LoginView.vue'),
      meta: { public: true },
    },
    {
      path: '/',
      component: () => import('@/layout/MainLayout.vue'),
      children: [
        { path: '', redirect: '/dashboard' },
        { path: 'dashboard', name: 'dashboard', component: () => import('@/views/dashboard/DashboardView.vue') },
        { path: 'users', name: 'users', component: () => import('@/views/users/UserManagementView.vue') },
        { path: 'users/:userId', name: 'user-detail', component: () => import('@/views/users/UserDetailView.vue') },
        { path: 'roles', name: 'roles', component: () => import('@/views/roles/RoleManagementView.vue') },
        { path: 'permissions', name: 'permissions', component: () => import('@/views/permissions/PermissionManagementView.vue') },
        { path: 'devices', name: 'devices', component: () => import('@/views/devices/DeviceManagementView.vue') },
        { path: 'devices/:deviceId', name: 'device-detail', component: () => import('@/views/devices/DeviceDetailView.vue') },
        { path: 'ota', name: 'ota', component: () => import('@/views/ota/OtaSettingsView.vue') },
        { path: 'ota/:otaId', name: 'ota-detail', component: () => import('@/views/ota/OtaDetailView.vue') },
      ],
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'not-found',
      component: () => import('@/views/errors/NotFoundView.vue'),
      meta: { public: true },
    },
  ],
})

router.beforeEach((to) => {
  const authStore = useAuthStore()
  if (!to.meta.public && !authStore.isAuthenticated) {
    return { path: '/login', query: { redirect: to.fullPath } }
  }
  if (to.path === '/login' && authStore.isAuthenticated) {
    return '/dashboard'
  }
  return true
})

export default router
