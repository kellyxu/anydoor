<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ArrowDown } from '@element-plus/icons-vue'
import { useAuthStore } from '@/stores/auth'

const route = useRoute()
const router = useRouter()
const authStore = useAuthStore()

type MenuItem = {
  path: string
  label: string
}

type BreadcrumbItem = {
  label: string
  to?: string
}

const menuItems: MenuItem[] = [
  { path: '/dashboard', label: '数据仪表盘' },
  { path: '/users', label: '用户管理' },
  { path: '/roles', label: '角色管理' },
  { path: '/permissions', label: '权限管理' },
  { path: '/devices', label: '设备管理' },
  { path: '/ota', label: 'OTA 设置' },
]

const titleMap: Record<string, string> = {
  dashboard: '数据仪表盘',
  users: '用户管理',
  roles: '角色管理',
  permissions: '权限管理',
  devices: '设备管理',
  ota: 'OTA 设置',
}

const activeMenu = computed(() => {
  const path = route.path
  if (path.startsWith('/users/')) return '/users'
  if (path.startsWith('/devices/')) return '/devices'
  if (path.startsWith('/ota/')) return '/ota'
  if (path === '/') return '/dashboard'
  return `/${path.split('/')[1]}`
})

const breadcrumbList = computed<BreadcrumbItem[]>(() => {
  const segments = route.path.split('/').filter(Boolean)
  if (segments.length === 0) {
    return [{ label: '首页', to: '/' }, { label: '数据仪表盘' }]
  }
  const items: BreadcrumbItem[] = [{ label: '首页', to: '/' }]
  segments.forEach((segment, index) => {
    const isLast = index === segments.length - 1
    const to = `/${segments.slice(0, index + 1).join('/')}`
    items.push({
      label: titleMap[segment] ?? segment,
      to: isLast ? undefined : to,
    })
  })
  return items
})

function goMenu(path: string) {
  router.push(path)
}

function onLogout() {
  authStore.logout()
  router.replace('/login')
}
</script>

<template>
  <el-container class="layout-wrap">
    <el-aside width="240px" class="layout-aside">
      <div class="layout-logo">
        <img src="/tongyu-logo.svg" alt="瞳宇" class="layout-logo__icon" />
        <span class="layout-logo__text">瞳宇后台管理系统</span>
      </div>
      <el-menu
        :default-active="activeMenu"
        class="layout-menu"
        background-color="#0f1b2d"
        text-color="#c7d2e5"
        active-text-color="#5b9bff"
        @select="goMenu"
      >
        <el-menu-item v-for="item in menuItems" :key="item.path" :index="item.path">
          <span>{{ item.label }}</span>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header class="layout-header">
        <h2 class="layout-title">瞳宇后台管理系统</h2>
        <el-dropdown trigger="click" @command="onLogout">
          <span class="layout-user">
            {{ authStore.currentUser?.name ?? '当前用户' }}
            <el-icon><ArrowDown /></el-icon>
          </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="logout">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </el-header>

      <el-main class="layout-main">
        <el-breadcrumb separator="/" class="layout-breadcrumb">
          <el-breadcrumb-item
            v-for="item in breadcrumbList"
            :key="item.label + (item.to ?? 'last')"
            :to="item.to"
          >
            {{ item.label }}
          </el-breadcrumb-item>
        </el-breadcrumb>
        <div class="layout-content">
          <RouterView />
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<style scoped>
.layout-wrap {
  min-height: 100vh;
}

.layout-aside {
  background: #0f1b2d;
  box-shadow: 2px 0 8px rgb(0 0 0 / 8%);
}

.layout-logo {
  height: 64px;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 0 14px;
}

.layout-logo__icon {
  width: 28px;
  height: 28px;
  border-radius: 6px;
}

.layout-logo__text {
  color: #fff;
  font-size: 15px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.layout-menu {
  border-right: none;
}

.layout-header {
  height: 64px;
  background: #fff;
  border-bottom: 1px solid #edf2f7;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
}

.layout-title {
  margin: 0;
  font-size: 18px;
}

.layout-user {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
  color: #2c3e50;
}

.layout-main {
  background: #f5f7fb;
  padding: 16px;
}

.layout-breadcrumb {
  margin-bottom: 12px;
}

.layout-content {
  min-height: calc(100vh - 64px - 32px - 32px);
  background: #fff;
  border-radius: 8px;
  padding: 16px;
}
</style>
