import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import { dashboardStats, devices, otaPlans, permissions, roles, users } from '@/mock/data'

export const useAppStore = defineStore('app', () => {
  const dashboardList = ref(dashboardStats)
  const userList = ref(users)
  const roleList = ref(roles)
  const permissionList = ref(permissions)
  const deviceList = ref(devices)
  const otaList = ref(otaPlans)

  const roleMap = computed(() => new Map(roleList.value.map((role) => [role.id, role])))

  const onlineDeviceCount = computed(
    () => deviceList.value.filter((device) => device.status === 'online').length,
  )
  const offlineDeviceCount = computed(
    () => deviceList.value.filter((device) => device.status === 'offline').length,
  )
  const warningDeviceCount = computed(
    () => deviceList.value.filter((device) => device.status === 'warning').length,
  )

  function getUserById(userId: string) {
    return userList.value.find((user) => user.id === userId)
  }

  function getDeviceById(deviceId: string) {
    return deviceList.value.find((device) => device.id === deviceId)
  }

  function getDevicesByOwnerId(userId: string) {
    return deviceList.value.filter((device) => device.ownerUserId === userId)
  }

  function getOtaById(otaId: string) {
    return otaList.value.find((task) => task.id === otaId)
  }

  function getOtaByOperatorId(userId: string) {
    return otaList.value.filter((task) => task.operatorUserId === userId)
  }

  return {
    dashboardStats: dashboardList,
    userList,
    roleList,
    permissionList,
    deviceList,
    otaList,
    roleMap,
    onlineDeviceCount,
    offlineDeviceCount,
    warningDeviceCount,
    getUserById,
    getDeviceById,
    getDevicesByOwnerId,
    getOtaById,
    getOtaByOperatorId,
  }
})
