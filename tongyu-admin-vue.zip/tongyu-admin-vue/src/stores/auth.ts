import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import { users } from '@/mock/data'

const AUTH_STORAGE_KEY = 'tongyu-vue-current-user'

export const useAuthStore = defineStore('auth', () => {
  const currentUserId = ref<string | null>(localStorage.getItem(AUTH_STORAGE_KEY))

  const currentUser = computed(() =>
    users.find((user) => user.id === currentUserId.value && user.status === 'active'),
  )

  const isAuthenticated = computed(() => Boolean(currentUser.value))

  const login = (username: string, password: string) => {
    const matchedUser = users.find(
      (user) => user.email.toLowerCase() === username.toLowerCase() && user.status === 'active',
    )
    if (!matchedUser || password !== '123456') {
      return false
    }
    currentUserId.value = matchedUser.id
    localStorage.setItem(AUTH_STORAGE_KEY, matchedUser.id)
    return true
  }

  const logout = () => {
    currentUserId.value = null
    localStorage.removeItem(AUTH_STORAGE_KEY)
  }

  return {
    currentUserId,
    currentUser,
    isAuthenticated,
    login,
    logout,
  }
})
